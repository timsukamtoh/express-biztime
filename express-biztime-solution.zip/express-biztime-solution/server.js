const app = require("./app");

app.listen(3000, function () {
  console.log("Started http://localhost:3000/");
});
